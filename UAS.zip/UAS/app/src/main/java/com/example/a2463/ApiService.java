package com.example.a2463;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiService {
    @GET("eventspastleague.php?id=4328")
    Call<FootballResponse> getPlayingMovie(@Query("api_key") String apiKey);

    Call<FootballResponse> getPlayingFootball(String d58845c9d53da3e216a0a21300e1e90a);
}