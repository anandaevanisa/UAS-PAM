package com.example.a2463;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class FootballResponse {
    @SerializedName("events")
    private ArrayList<Football> events;

    @SerializedName("total_events")
    private int total_events;

    public ArrayList<Football> getEvents() {
        return events;
    }

    public int getTotal_events() {
        return total_events;
    }

    public void setEvents(ArrayList<Football> events) {
        this.events = events;
    }

    public void setTotal_events(int total_events) {
        this.total_events = total_events;
    }
}