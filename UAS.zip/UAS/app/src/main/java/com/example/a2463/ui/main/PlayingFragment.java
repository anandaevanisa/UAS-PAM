package com.example.a2463.ui.main;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.a2463.ApiClient;
import com.example.a2463.ApiService;
import com.example.a2463.Football;
import com.example.a2463.FootballAdapter;
import com.example.a2463.FootballResponse;
import com.example.a2463.R;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static java.security.AccessController.getContext;

public class PlayingFragment extends Fragment {

    private ArrayList<Football> listFootball;
    private RecyclerView rvFootball;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_playing, container, false);
        rvFootball = view.findViewById(R.id.rv_football);
        rvFootball.setHasFixedSize(true);
        rvFootball.setLayoutManager(new LinearLayoutManager(getContext()));

        ApiService service = ApiClient.getRetrofitInstance().create(ApiService.class);
        Call<FootballResponse> call = service.getPlayingFootball("1");
        call.enqueue(new Callback<FootballResponse>() {
            @Override
            public void onResponse(Call<FootballResponse> call, Response<FootballResponse> response) {

                listFootball = response.body().getEvents();

                FootballAdapter footballAdapter = new FootballAdapter(listFootball);
                rvFootball.setAdapter(footballAdapter);
            }

            @Override
            public void onFailure(Call<FootballResponse> call, Throwable t) {
            }
        });



        return view;
    }
}